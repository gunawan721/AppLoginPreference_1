![photo_2020-06-17_19-17-28](https://user-images.githubusercontent.com/37768182/84897639-25acf700-b0d0-11ea-9601-f48cb6391911.jpg)
![photo_2020-06-17_19-17-28 (2)](https://user-images.githubusercontent.com/37768182/84897648-29d91480-b0d0-11ea-93d1-cd90dc4fe045.jpg)
![photo_2020-06-17_19-17-28 (3)](https://user-images.githubusercontent.com/37768182/84897660-2d6c9b80-b0d0-11ea-897c-1ccf1b83d73a.jpg)# AppLoginPreference
